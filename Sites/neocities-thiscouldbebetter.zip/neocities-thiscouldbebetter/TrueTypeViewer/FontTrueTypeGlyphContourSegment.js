
function FontTrueTypeGlyphContourSegment(startPoint, curveControlPoint)
{
	this.startPoint = startPoint;
	this.curveControlPoint = curveControlPoint;
}
