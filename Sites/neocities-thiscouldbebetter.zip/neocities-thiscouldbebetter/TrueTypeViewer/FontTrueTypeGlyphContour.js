
function FontTrueTypeGlyphContour(segments)
{
	this.segments = segments;
}
