
function FontTrueTypeLocationTable(offsets)
{
	this.offsets = offsets;
}
