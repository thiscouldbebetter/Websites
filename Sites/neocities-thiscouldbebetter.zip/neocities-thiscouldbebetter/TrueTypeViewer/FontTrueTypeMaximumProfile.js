
function FontTrueTypeMaximumProfile(numberOfGlyphs)
{
	this.numberOfGlyphs = numberOfGlyphs;
}
