
function FontTrueTypeGlyphContourPoint(position, isOnCurve)
{
	this.position = position;
	this.isOnCurve = isOnCurve;
}
