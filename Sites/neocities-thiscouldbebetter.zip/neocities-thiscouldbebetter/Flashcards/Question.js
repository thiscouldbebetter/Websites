
function Question(presentation, responseCorrect, context)
{
	this.presentation = presentation;
	this.responseCorrect = responseCorrect;
	this.context = context;
}
