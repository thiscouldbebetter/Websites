
function ResponseRecord()
{
	this.timesIncorrect = 0;
	this.timesCorrect = 0;
}
