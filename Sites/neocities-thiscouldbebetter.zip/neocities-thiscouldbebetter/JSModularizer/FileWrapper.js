
function FileWrapper(name, isTextRatherThanBinary, contents)
{
	this.name = name;
	this.isTextRatherThanBinary = isTextRatherThanBinary;
	this.contents = contents;
}
