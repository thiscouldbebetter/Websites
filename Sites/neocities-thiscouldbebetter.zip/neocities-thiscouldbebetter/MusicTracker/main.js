function main()
{
	Tracker.Instance.uiUpdate();
}
