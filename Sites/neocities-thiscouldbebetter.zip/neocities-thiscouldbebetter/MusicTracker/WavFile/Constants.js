
// constants

function Constants()
{
	// static class
}

{
	Constants.BitsPerByte = 8;
	Constants.BitsPerByteTimesTwo = Constants.BitsPerByte * 2;
	Constants.BitsPerByteTimesThree = Constants.BitsPerByte * 3;
	Constants.Newline = "\r\n";

}
