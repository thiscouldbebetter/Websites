
function Empty(pos)
{
	this.pos = pos;
}
