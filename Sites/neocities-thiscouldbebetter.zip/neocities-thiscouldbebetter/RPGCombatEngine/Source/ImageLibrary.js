
function ImageLibrary(images)
{
	this.images = images;
	this.images.addLookups("name");
}
