
function SpellDefn(name, apply)
{
	this.name = name;
	this.apply = apply;
}
