
function ItemDefn(name, categoryNames, apply)
{
	this.name = name;
	this.categoryNames = categoryNames;
	this.apply = apply;
}
