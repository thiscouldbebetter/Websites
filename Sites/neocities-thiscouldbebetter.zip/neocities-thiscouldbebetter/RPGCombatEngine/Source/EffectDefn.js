
function EffectDefn(name, apply)
{
	this.name = name;
	this.apply = apply;
}
