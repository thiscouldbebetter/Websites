
function Message(text, pos)
{
	this.text = text;
	this.pos = pos;

	this.ticksToLive = 100;
}
