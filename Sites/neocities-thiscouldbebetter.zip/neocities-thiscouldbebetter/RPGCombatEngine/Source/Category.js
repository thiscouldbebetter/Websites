
function Category(name)
{
	this.name = name;
}
